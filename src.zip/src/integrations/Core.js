// src/integrations/Core.js

// This simulates an API call to send an email without needing a real server.
export const SendEmail = (emailData) => {
    console.log("Simulating email send...");
    console.log("Email to:", emailData.to);
    console.log("Subject:", emailData.subject);

    // We will simulate a 1-second network delay
    return new Promise((resolve) => {
        setTimeout(() => {
            // This will always resolve successfully for now!
            resolve({ status: 200, message: "Email simulated successfully" });
        }, 1000);
    });
};