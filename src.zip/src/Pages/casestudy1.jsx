
import React from "react";
/* eslint-disable-next-line no-unused-vars */
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Mountain,
  Target,
  Lightbulb,
  Code2,
  Brain,
  TrendingUp,
  Users,
  Zap,
  CheckCircle,
  AlertTriangle,
  Rocket,
  MapPin,
  Cloud,
  Smartphone
} from "lucide-react";

export default function HappyTrailsCaseStudy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-green-50 to-blue-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-600 via-blue-600 to-green-700 text-white py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <Link to={createPageUrl("Portfolio")}>
            <Button variant="ghost" className="text-white hover:bg-white/20 mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Portfolio
            </Button>
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                <Mountain className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-5xl font-bold">Happy Trails</h1>
                <p className="text-xl text-green-100">AI-Powered Hiking Companion App</p>
              </div>
            </div>
            <p className="text-lg text-white/90 max-w-3xl mt-6">
              An intelligent hiking companion that leverages AI to provide personalized trail recommendations, 
              real-time safety alerts, and community-driven insights for outdoor enthusiasts.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-16">
        {/* Overview Stats */}
        <motion.div
          className="grid md:grid-cols-4 gap-6 mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          {[
            { icon: Users, label: "Target Users", value: "5k+", color: "from-blue-500 to-blue-600" },
            { icon: TrendingUp, label: "Engagement Rate", value: "85%", color: "from-green-500 to-green-600" },
            { icon: Mountain, label: "Trail Database", value: "5,000+", color: "from-purple-500 to-purple-600" },
            { icon: Zap, label: "AI Accuracy", value: "92%", color: "from-orange-500 to-red-500" }
          ].map((stat) => (
            <Card key={stat.label} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Problem Statement */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">The Problem</h2>
              </div>
              <div className="space-y-4 text-gray-700 leading-relaxed">
                <p className="text-lg">
                  Outdoor enthusiasts struggle with finding appropriate trails that match their skill level, 
                  preferences, and current conditions. Existing hiking apps lack personalization and fail to 
                  provide real-time safety information or intelligent recommendations.
                </p>
                <div className="grid md:grid-cols-2 gap-4 mt-6">
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h3 className="font-semibold text-red-800 mb-2">Pain Points Identified:</h3>
                    <ul className="space-y-2 text-sm text-red-700">
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Generic trail recommendations that don't consider individual fitness levels</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Lack of real-time weather and safety alerts for remote areas</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Limited offline functionality in areas with no cell coverage</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Fragmented information across multiple platforms</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-semibold text-blue-800 mb-2">User Research Insights:</h3>
                    <ul className="space-y-2 text-sm text-blue-700">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>73% want personalized recommendations based on past hikes</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>89% prioritize safety features and emergency protocols</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>70% frustrated by outdated trail condition information</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>82% would use community features to connect with hikers</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Key Challenges */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Key Challenges</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  {
                    title: "Offline-First Architecture",
                    description: "Building a robust offline experience while maintaining data sync for remote hiking areas with limited connectivity",
                    challenge: "Balancing comprehensive trail data with app performance and storage constraints"
                  },
                  {
                    title: "AI Personalization at Scale",
                    description: "Creating ML models that learn user preferences without compromising privacy or requiring excessive data collection",
                    challenge: "Training recommendation engine with limited initial user data"
                  },
                  {
                    title: "Real-Time Safety Integration",
                    description: "Integrating multiple weather APIs and emergency services while ensuring low latency and reliability",
                    challenge: "Handling API failures gracefully in critical safety scenarios"
                  },
                  {
                    title: "Community Data Quality",
                    description: "Maintaining accurate, up-to-date trail conditions through user-generated content without spam or misinformation",
                    challenge: "Implementing content moderation while encouraging community participation"
                  }
                ].map((challenge, index) => (
                  <div key={index} className="bg-gradient-to-br from-orange-50 to-red-50 rounded-lg p-6 border border-orange-200">
                    <h3 className="font-bold text-gray-900 mb-2">{challenge.title}</h3>
                    <p className="text-gray-700 mb-3">{challenge.description}</p>
                    <div className="bg-white/60 rounded-lg p-3 border border-orange-300">
                      <p className="text-sm font-medium text-orange-800">
                        <span className="font-bold">Challenge: </span>{challenge.challenge}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Solution Approach */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Solution Approach</h2>
              </div>
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6 border border-green-200">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Brain className="w-5 h-5 text-green-600" />
                    AI-Powered Personalization Engine
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Developed a hybrid recommendation system combining collaborative filtering with content-based ML models 
                    to provide personalized trail suggestions based on:
                  </p>
                  <ul className="grid md:grid-cols-2 gap-3">
                    {[
                      "User fitness level and hiking history",
                      "Weather conditions and seasonal factors",
                      "Trail difficulty, length, and elevation",
                      "User preferences (scenery, wildlife, crowds)",
                      "Real-time trail conditions from community",
                      "Similar user behavioral patterns"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Cloud className="w-5 h-5 text-blue-600" />
                    Smart Caching & Offline Architecture
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Implemented progressive data loading and intelligent caching strategy:
                  </p>
                  <ul className="space-y-2">
                    {[
                      "User can pre-download trail data for specific regions before hiking",
                      "Automatic background sync when connected to WiFi",
                      "Local SQLite database for offline access to favorites and history",
                      "Compressed map tiles with on-demand loading for optimal storage"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <Zap className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-6 border border-purple-200">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-purple-600" />
                    Real-Time Safety & Emergency Features
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Built comprehensive safety system with multi-layered alerts:
                  </p>
                  <ul className="space-y-2">
                    {[
                      "Integration with NOAA weather API for hyper-local forecasts",
                      "Emergency SOS with GPS coordinates sent to designated contacts",
                      "Automatic trail condition alerts based on recent user reports",
                      "Offline emergency protocols with pre-loaded safety information"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <AlertTriangle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Technology Stack */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                  <Code2 className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Technology Stack</h2>
              </div>
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  {
                    category: "Frontend",
                    icon: Smartphone,
                    color: "from-blue-500 to-blue-600",
                    technologies: ["React Native", "TypeScript", "Redux Toolkit", "React Navigation", "Mapbox GL"]
                  },
                  {
                    category: "Backend & Cloud",
                    icon: Cloud,
                    color: "from-purple-500 to-purple-600",
                    technologies: ["Firebase", "AWS Lambda", "PostgreSQL", "Redis Cache", "Node.js"]
                  },
                  {
                    category: "AI/ML & APIs",
                    icon: Brain,
                    color: "from-green-500 to-green-600",
                    technologies: ["OpenAI API", "TensorFlow Lite", "NOAA Weather API", "Google Maps API", "Scikit-learn"]
                  }
                ].map((stack, index) => (
                  <div key={index} className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg p-6 border border-gray-200">
                    <div className={`w-10 h-10 bg-gradient-to-r ${stack.color} rounded-lg flex items-center justify-center mb-4`}>
                      <stack.icon className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-bold text-gray-900 mb-3">{stack.category}</h3>
                    <div className="space-y-2">
                      {stack.technologies.map((tech, i) => (
                        <Badge key={i} variant="secondary" className="mr-2 mb-2">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* AI/ML Models Used */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">AI/ML Models & Techniques</h2>
              </div>
              <div className="space-y-4">
                {[
                  {
                    model: "Collaborative Filtering Recommender",
                    purpose: "Trail recommendations based on similar user preferences and hiking patterns",
                    implementation: "Matrix factorization with implicit feedback from user interactions",
                    result: "92% recommendation accuracy based on user feedback"
                  },
                  {
                    model: "Natural Language Processing (NLP)",
                    purpose: "Analyze user reviews and trail descriptions for sentiment and key features",
                    implementation: "Fine-tuned BERT model for outdoor activity context understanding",
                    result: "Extracted key features (difficulty, scenery type, crowd levels) from reviews"
                  },
                  {
                    model: "RAG Pipeline for Trail Information",
                    purpose: "Provide intelligent answers to user queries about trails and hiking conditions",
                    implementation: "Vector embeddings with OpenAI API for semantic search across trail database",
                    result: "Reduced user search time by 40% with contextual answers"
                  },
                  {
                    model: "Computer Vision for Wildlife Detection",
                    purpose: "Identify wildlife from user-submitted photos for safety alerts",
                    implementation: "TensorFlow Lite model running on-device for real-time detection",
                    result: "85% accuracy in identifying wildlife"
                  }
                ].map((model, index) => (
                  <div key={index} className="bg-white rounded-lg p-6 border border-purple-200 shadow-sm">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-bold text-gray-900 text-lg">{model.model}</h3>
                      <Badge className="bg-purple-100 text-purple-700">
                        {model.result.split(' ')[0]}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Purpose:</span> {model.purpose}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Implementation:</span> {model.implementation}
                      </p>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-3">
                        <p className="text-sm font-medium text-green-800">
                          <CheckCircle className="w-4 h-4 inline mr-2" />
                          {model.result}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* User Impact */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">User Impact & Results</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-bold text-gray-900 text-xl mb-4">Quantifiable Metrics</h3>
                  {[
                    { metric: "User Engagement", value: "85%", description: "of users actively use the app weekly" },
                    { metric: "Recommendation Accuracy", value: "92%", description: "users rate AI suggestions as helpful" },
                    { metric: "Safety Feature Adoption", value: "78%", description: "users enable emergency contact features" },
                    { metric: "Offline Usage", value: "68%", description: "of hikes completed with offline features" }
                  ].map((item, i) => (
                    <div key={i} className="bg-white rounded-lg p-4 border border-green-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">{item.metric}</span>
                        <span className="text-2xl font-bold text-green-600">{item.value}</span>
                      </div>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                  ))}
                </div>
                <div className="space-y-4">
                  <h3 className="font-bold text-gray-900 text-xl mb-4">User Testimonials</h3>
                  {[
                    {
                      quote: "The AI recommendations are spot-on! It suggested trails I never would have found on my own.",
                      user: "Chelsea R., Avid Hiker"
                    },
                    {
                      quote: "The offline features saved me when I got lost. Having the maps and emergency info was crucial.",
                      user: "Michael K., Backpacker"
                    },
                    {
                      quote: "I love how it learns my preferences. Every suggestion gets better and matches my skill level perfectly.",
                      user: "Jessica L., Weekend Warrior"
                    }
                  ].map((testimonial, i) => (
                    <div key={i} className="bg-white rounded-lg p-4 border border-blue-200">
                      <p className="text-gray-700 italic mb-3">"{testimonial.quote}"</p>
                      <p className="text-sm font-medium text-blue-700">— {testimonial.user}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Future Iterations */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <Rocket className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Future Iterations & Roadmap</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  {
                    phase: "Phase 1 - Enhanced AI",
                    features: [
                      "Multimodal AI for photo-based trail condition assessment",
                      "Voice-activated trail assistant for hands-free navigation",
                      "Predictive crowd forecasting using ML",
                      "AR wayfinding overlays for complex trail junctions"
                    ]
                  },
                  {
                    phase: "Phase 2 - Social & Gamification",
                    features: [
                      "Social hiking groups with AI-matched companions",
                      "Achievement badges and challenge system",
                      "Live trail condition crowdsourcing",
                      "Integration with fitness wearables (Apple Watch, Garmin)"
                    ]
                  },
                  {
                    phase: "Phase 3 - Ecosystem Expansion",
                    features: [
                      "Partnership with national parks for official trail data",
                      "Premium tier with advanced AI features",
                      "International trail expansion (Europe, Asia)",
                      "B2B offerings for outdoor tourism companies"
                    ]
                  },
                  {
                    phase: "Phase 4 - Advanced Features",
                    features: [
                      "AI-powered trip planning with multi-day itineraries",
                      "Carbon footprint tracking and eco-friendly suggestions",
                      "Integration with emergency services for faster response",
                      "Advanced weather ML models for micro-climate predictions"
                    ]
                  }
                ].map((phase, index) => (
                  <div key={index} className="bg-white rounded-lg p-6 border border-blue-200">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {index + 1}
                      </div>
                      <h3 className="font-bold text-gray-900">{phase.phase}</h3>
                    </div>
                    <ul className="space-y-2">
                      {phase.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                          <Rocket className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* CTA Section */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-r from-green-600 to-blue-600 border-0 shadow-2xl">
            <CardContent className="p-12 text-white">
              <Mountain className="w-16 h-16 mx-auto mb-6 opacity-80" />
              <h2 className="text-3xl font-bold mb-4">Interested in Learning More?</h2>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
                Let's discuss how I can bring AI product engineering expertise to your team!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to={createPageUrl("Portfolio")}>
                  <Button size="lg" className="bg-white text-green-900 hover:bg-green-50">
  View More Projects
</Button>
                </Link>
                <Link to={createPageUrl("Portfolio") + "#contact"}>
                  <Button 
                    size="lg" 
                    className="bg-white/20 backdrop-blur-sm border-2 border-white text-white hover:bg-white hover:text-green-600 transition-all"
                  >
                    Get in Touch
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
