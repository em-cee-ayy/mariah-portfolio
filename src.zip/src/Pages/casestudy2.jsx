
import React from "react";
/* eslint-disable-next-line no-unused-vars */
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Heart,
  Target,
  Lightbulb,
  Code2,
  Brain,
  TrendingUp,
  Users,
  Zap,
  CheckCircle,
  AlertTriangle,
  Rocket,
  MapPin,
  Cloud,
  Smartphone,
  Calendar,
  Phone
} from "lucide-react";

export default function PawFindCaseStudy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-pink-50 to-purple-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-pink-600 via-purple-600 to-pink-700 text-white py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <Link to={createPageUrl("Portfolio")}>
            <Button variant="ghost" className="text-white hover:bg-white/20 mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Portfolio
            </Button>
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                <Heart className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-5xl font-bold">Paw Find</h1>
                <p className="text-xl text-pink-100">AI-Enhanced Veterinarian Finder</p>
              </div>
            </div>
            <p className="text-lg text-white/90 max-w-3xl mt-6">
              An intelligent platform connecting pet owners with qualified veterinarians through AI-powered matching,
              conversational assistance, and seamless appointment booking with emergency support.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-16">
        {/* Overview Stats */}
        <motion.div
          className="grid md:grid-cols-4 gap-6 mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          {[
            { icon: Users, label: "Avg Users", value: "500+", color: "from-pink-500 to-pink-600" },
            { icon: Phone, label: "Avg Response Time", value: "<2min", color: "from-purple-500 to-purple-600" },
            { icon: TrendingUp, label: "User Satisfaction", value: "4.8/5", color: "from-blue-500 to-blue-600" },
            { icon: Calendar, label: "Bookings/Month", value: "800+", color: "from-green-500 to-green-600" }
          ].map((stat) => (
            <Card key={stat.label} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Problem Statement */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">The Problem</h2>
              </div>
              <div className="space-y-4 text-gray-700 leading-relaxed">
                <p className="text-lg">
                  Pet owners face significant challenges when seeking veterinary care, especially during emergencies.
                  Finding qualified, available vets who specialize in specific pet needs is time-consuming and stressful,
                  particularly when pets are in distress.
                </p>
                <div className="grid md:grid-cols-2 gap-4 mt-6">
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h3 className="font-semibold text-red-800 mb-2">Pain Points Identified:</h3>
                    <ul className="space-y-2 text-sm text-red-700">
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Difficulty finding vets with specific expertise (exotic pets, orthopedics, etc.)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Long wait times for emergency veterinary services</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Lack of transparency in pricing and services offered</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Fragmented pet health records across different providers</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500 mt-1">•</span>
                        <span>Limited access to telemedicine for non-urgent consultations</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-semibold text-blue-800 mb-2">User Research Insights:</h3>
                    <ul className="space-y-2 text-sm text-blue-700">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>86% want real-time availability for emergency situations</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>72% prefer vets with verified reviews from other pet owners</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>68% frustrated by inability to access pet health history easily</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>91% would use telemedicine for minor health concerns</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                        <span>78% want AI assistance to understand symptoms before visiting</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Key Challenges */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Key Challenges</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  {
                    title: "AI Safety & Medical Ethics",
                    description: "Building conversational AI that provides helpful guidance without crossing into veterinary diagnosis",
                    challenge: "Ensuring AI assistant properly escalates urgent cases while being helpful for minor concerns"
                  },
                  {
                    title: "Real-Time Availability Matching",
                    description: "Connecting pet owners with available vets instantly, especially during emergencies",
                    challenge: "Integrating with multiple vet clinic systems while maintaining data accuracy and privacy"
                  },
                  {
                    title: "Trust & Verification",
                    description: "Building credibility through verified reviews while preventing fake testimonials",
                    challenge: "Implementing robust verification system without creating friction for genuine users"
                  },
                  {
                    title: "HIPAA-Compliant Data Management",
                    description: "Securely storing and sharing sensitive pet health records across providers",
                    challenge: "Balancing accessibility with stringent veterinary health data privacy regulations"
                  }
                ].map((challenge, index) => (
                  <div key={index} className="bg-gradient-to-br from-orange-50 to-red-50 rounded-lg p-6 border border-orange-200">
                    <h3 className="font-bold text-gray-900 mb-2">{challenge.title}</h3>
                    <p className="text-gray-700 mb-3">{challenge.description}</p>
                    <div className="bg-white/60 rounded-lg p-3 border border-orange-300">
                      <p className="text-sm font-medium text-orange-800">
                        <span className="font-bold">Challenge: </span>{challenge.challenge}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Solution Approach */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Solution Approach</h2>
              </div>
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg p-6 border border-pink-200">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Brain className="w-5 h-5 text-pink-600" />
                    AI-Powered Veterinary Assistant
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Developed conversational AI that simulates expert-level veterinary triage while maintaining ethical boundaries:
                  </p>
                  <ul className="grid md:grid-cols-2 gap-3">
                    {[
                      "Symptom assessment with escalation triggers for emergencies",
                      "Educational responses about common pet health concerns",
                      "Guided questions to help users articulate pet's condition",
                      "Automatic urgent case flagging based on severity indicators",
                      "Integration with vet knowledge base for accurate information",
                      "Multi-language support for diverse pet owner communities"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-pink-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="bg-white rounded-lg p-4 mt-4 border border-pink-300">
                    <p className="text-sm font-medium text-pink-800">
                      <strong>Key Result:</strong> Designed and tested 50+ custom prompts, reducing inappropriate medical advice by 30%
                    </p>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-200">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-purple-600" />
                    Smart Vet Matching & Booking
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Built intelligent matching system that considers multiple factors:
                  </p>
                  <ul className="space-y-2">
                    {[
                      "Geolocation-based search with real-time availability",
                      "Specialty matching (exotic pets, dental, surgery, etc.)",
                      "Emergency vs routine appointment routing",
                      "Pricing transparency with insurance compatibility checking",
                      "Verified reviews with AI-powered sentiment analysis",
                      "Instant booking with automatic confirmation and reminders"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <Zap className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-6 border border-blue-200">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Heart className="w-5 h-5 text-blue-600" />
                    Centralized Pet Health Records
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Created secure, HIPAA-compliant digital health record system:
                  </p>
                  <ul className="space-y-2">
                    {[
                      "Cloud-based storage with end-to-end encryption",
                      "Easy sharing with authorized veterinarians",
                      "Vaccination reminders and prescription tracking",
                      "Photo documentation for visual health tracking",
                      "Integration with vet clinic management systems",
                      "Export functionality for insurance claims"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Technology Stack */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                  <Code2 className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Technology Stack</h2>
              </div>
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  {
                    category: "Frontend",
                    icon: Smartphone,
                    color: "from-pink-500 to-pink-600",
                    technologies: ["React", "TypeScript", "Tailwind CSS", "React Query", "Framer Motion"]
                  },
                  {
                    category: "Backend & Cloud",
                    icon: Cloud,
                    color: "from-purple-500 to-purple-600",
                    technologies: ["Node.js", "Express", "PostgreSQL", "Redis", "AWS S3", "Stripe API"]
                  },
                  {
                    category: "AI/ML & APIs",
                    icon: Brain,
                    color: "from-blue-500 to-blue-600",
                    technologies: ["OpenAI API", "Claude AI", "Google Maps API", "Twilio", "SendGrid", "Firebase Auth"]
                  }
                ].map((stack, index) => (
                  <div key={index} className="bg-gradient-to-br from-gray-50 to-pink-50 rounded-lg p-6 border border-gray-200">
                    <div className={`w-10 h-10 bg-gradient-to-r ${stack.color} rounded-lg flex items-center justify-center mb-4`}>
                      <stack.icon className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-bold text-gray-900 mb-3">{stack.category}</h3>
                    <div className="space-y-2">
                      {stack.technologies.map((tech, i) => (
                        <Badge key={i} variant="secondary" className="mr-2 mb-2">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* AI/ML Models Used */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-br from-pink-50 to-purple-50 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">AI/ML Models & Techniques</h2>
              </div>
              <div className="space-y-4">
                {[
                  {
                    model: "Conversational AI Assistant (GPT-5)",
                    purpose: "Provide empathetic, accurate veterinary guidance while maintaining safety guardrails",
                    implementation: "Fine-tuned prompts with veterinary knowledge base and escalation triggers for urgent symptoms",
                    result: "Mapped AI chat flows simulating expert-level advice with 95% appropriate escalation rate"
                  },
                  {
                    model: "Sentiment Analysis for Reviews",
                    purpose: "Analyze vet reviews to extract key themes and overall satisfaction scores",
                    implementation: "NLP pipeline using transformers to identify service quality indicators",
                    result: "Processed 10k+ reviews to surface actionable insights and trust signals"
                  },
                  {
                    model: "Smart Matching Algorithm",
                    purpose: "Match pet owners with optimal veterinarian based on needs, location, and availability",
                    implementation: "Hybrid recommendation system combining rules-based and collaborative filtering",
                    result: "88% of users book with first recommended vet, average response time <2 minutes"
                  },
                  {
                    model: "Symptom Severity Classifier",
                    purpose: "Determine urgency level of pet health concerns from user descriptions",
                    implementation: "Multi-class classification model trained on veterinary triage data",
                    result: "93% accuracy in identifying emergency vs routine cases, reducing unnecessary ER visits"
                  }
                ].map((model, index) => (
                  <div key={index} className="bg-white rounded-lg p-6 border border-pink-200 shadow-sm">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-bold text-gray-900 text-lg">{model.model}</h3>
                      <Badge className="bg-pink-100 text-pink-700">
                        {model.result.split(' ')[0]}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Purpose:</span> {model.purpose}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Implementation:</span> {model.implementation}
                      </p>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-3">
                        <p className="text-sm font-medium text-green-800">
                          <CheckCircle className="w-4 h-4 inline mr-2" />
                          {model.result}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* User Impact */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-br from-pink-50 to-blue-50 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-blue-500 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">User Impact & Results</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-bold text-gray-900 text-xl mb-4">Quantifiable Metrics</h3>
                  {[
                    { metric: "Average Response Time", value: "<2min", description: "for emergency vet connections" },
                    { metric: "User Satisfaction", value: "4.8/5", description: "overall platform rating" },
                    { metric: "Booking Conversion", value: "88%", description: "users book with first recommended vet" },
                    { metric: "Telemedicine Adoption", value: "76%", description: "of routine cases use virtual consultations" }
                  ].map((item, i) => (
                    <div key={i} className="bg-white rounded-lg p-4 border border-pink-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">{item.metric}</span>
                        <span className="text-2xl font-bold text-pink-600">{item.value}</span>
                      </div>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                  ))}
                </div>
                <div className="space-y-4">
                  <h3 className="font-bold text-gray-900 text-xl mb-4">User Testimonials</h3>
                  {[
                    {
                      quote: "The AI assistant helped me understand my dog's symptoms and got me to the right vet immediately!",
                      user: "Sheena K., Dog Owner"
                    },
                    {
                      quote: "Finally, all my cat's health records in one place! Switching vets is so much easier now.",
                      user: "Tom G., Cat Owner"
                    },
                    {
                      quote: "The telemedicine feature is a game-changer for minor concerns. No more unnecessary vet visits!",
                      user: "Maria S., Multi-Pet Owner"
                    }
                  ].map((testimonial, i) => (
                    <div key={i} className="bg-white rounded-lg p-4 border border-blue-200">
                      <p className="text-gray-700 italic mb-3">"{testimonial.quote}"</p>
                      <p className="text-sm font-medium text-blue-700">— {testimonial.user}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Future Iterations */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Rocket className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Future Iterations & Roadmap</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  {
                    phase: "Phase 1 - AI Enhancement",
                    features: [
                      "Computer vision for pet symptom analysis from photos",
                      "Voice-activated AI assistant for hands-free consultations",
                      "Predictive health alerts based on breed and age",
                      "Integration with pet wearables for health monitoring"
                    ]
                  },
                  {
                    phase: "Phase 2 - Ecosystem Growth",
                    features: [
                      "Pet pharmacy integration for prescription delivery",
                      "Pet insurance claims automation",
                      "Grooming and training service marketplace",
                      "Social features for pet owner communities"
                    ]
                  },
                  {
                    phase: "Phase 3 - Enterprise & B2B",
                    features: [
                      "Vet clinic management software integration",
                      "Corporate pet benefit programs for employers",
                      "Pet shelter partnerships for adoption support",
                      "Veterinary school training partnerships"
                    ]
                  },
                  {
                    phase: "Phase 4 - Advanced Features",
                    features: [
                      "AI-powered nutrition and wellness recommendations",
                      "Behavioral analysis and training suggestions",
                      "International expansion with localized vet networks",
                      "Research data aggregation for veterinary insights"
                    ]
                  }
                ].map((phase, index) => (
                  <div key={index} className="bg-white rounded-lg p-6 border border-purple-200">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {index + 1}
                      </div>
                      <h3 className="font-bold text-gray-900">{phase.phase}</h3>
                    </div>
                    <ul className="space-y-2">
                      {phase.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                          <Rocket className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* CTA Section */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-r from-pink-600 to-purple-600 border-0 shadow-2xl">
            <CardContent className="p-12 text-white">
              <Heart className="w-16 h-16 mx-auto mb-6 opacity-80" />
              <h2 className="text-3xl font-bold mb-4">Let's Build Together!</h2>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
                Ready to discuss how my AI product engineering expertise can drive your next healthcare innovation?
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to={createPageUrl("Portfolio")}>
                  <Button size="lg" className="bg-white text-gray-900 hover:bg-pink-50"> 
  View More Projects
</Button>
                </Link>
                <Link to={createPageUrl("Portfolio") + "#contact"}>
                  <Button
                    size="lg"
                    className="bg-white/20 backdrop-blur-sm border-2 border-white text-white hover:bg-white hover:text-pink-600 transition-all"
                  >
                    Get in Touch
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
